/*
 * ============================================================
 *  implementation.cpp
 *  Smart Emergency Route Planner - Peshawar City
 *  CSE-210L Data Structures & Algorithms Lab
 *
 *  Author      : Sher Nawaz (24PWCSE2352)
 *  Department  : Computer Systems Engineering
 *  University  : UET Peshawar
 *
 *  All Graph member functions live here. main.cpp only calls
 *  these; it never touches adjacency lists or road-index
 *  bookkeeping directly.
 *
 *  NOTE: Written for Dev-C++ / older MinGW compilers -> no
 *        C++17-only syntax (no structured bindings, etc.)
 * ============================================================
 */

#include "implementation.h"
#include <iostream>
#include <queue>
#include <limits>
#include <iomanip>
#include <algorithm>

using namespace std;

typedef pair<int, int> pii;

// ─── Construction / setup ──────────────────────────────────────
Graph::Graph(int n) {
    numNodes = n;
    adj.resize(n);
    names.resize(n, "");
}

void Graph::setNumNodes(int n) {
    numNodes = n;
    adj.assign(n, vector<pii>());
    names.assign(n, "");
    nameToId.clear();
    roads.clear();
}

void Graph::addLocation(int id, const string& name) {
    if (id < 0 || id >= numNodes) return;
    names[id] = name;
    nameToId[name] = id;
}

int Graph::addRoad(int u, int v, int travelTimeMinutes) {
    RoadEdge e;
    e.u = u;
    e.v = v;
    e.weight = travelTimeMinutes;
    e.blocked = false;
    roads.push_back(e);
    int roadId = (int)roads.size() - 1;

    adj[u].push_back(make_pair(v, roadId));
    adj[v].push_back(make_pair(u, roadId));
    return roadId;
}

// ─── Lookups ────────────────────────────────────────────────────
string Graph::getName(int id) const {
    if (id < 0 || id >= (int)names.size()) return "Unknown";
    return names[id];
}

int Graph::getNumNodes() const { return numNodes; }

int Graph::getRoadCount() const { return (int)roads.size(); }

int Graph::findRoadId(int u, int v) const {
    for (size_t i = 0; i < roads.size(); i++) {
        bool matchesForward  = (roads[i].u == u && roads[i].v == v);
        bool matchesBackward = (roads[i].u == v && roads[i].v == u);
        if (matchesForward || matchesBackward) return (int)i;
    }
    return -1;
}

// ─── Road blocking feature ──────────────────────────────────────
bool Graph::blockRoad(int u, int v) {
    int id = findRoadId(u, v);
    if (id == -1) return false;
    roads[id].blocked = true;
    return true;
}

bool Graph::unblockRoad(int u, int v) {
    int id = findRoadId(u, v);
    if (id == -1) return false;
    roads[id].blocked = false;
    return true;
}

void Graph::listRoads() const {
    cout << "\n  Road List (" << roads.size() << " total)\n";
    cout << "  " << string(60, '-') << "\n";
    cout << left << setw(6) << "  ID" << setw(24) << "From" << setw(24) << "To"
         << setw(10) << "Time" << "Status\n";
    cout << "  " << string(60, '-') << "\n";
    for (size_t i = 0; i < roads.size(); i++) {
        cout << "  " << left << setw(4) << i
             << setw(24) << names[roads[i].u]
             << setw(24) << names[roads[i].v]
             << setw(10) << roads[i].weight
             << (roads[i].blocked ? "BLOCKED" : "open") << "\n";
    }
}

// ─── Dijkstra's Algorithm ───────────────────────────────────────
void Graph::dijkstra(int src, vector<int>& dist, vector<int>& prev) {
    dist.assign(numNodes, INF);
    prev.assign(numNodes, -1);

    // Min-heap: (distance, node) - smallest distance on top
    priority_queue<pii, vector<pii>, greater<pii> > minHeap;

    dist[src] = 0;
    minHeap.push(make_pair(0, src));

    while (!minHeap.empty()) {
        pii top = minHeap.top();
        minHeap.pop();
        int d = top.first;
        int u = top.second;

        if (d > dist[u]) continue; // stale entry, skip

        for (size_t i = 0; i < adj[u].size(); i++) {
            int v = adj[u][i].first;
            int roadId = adj[u][i].second;

            if (roads[roadId].blocked) continue; // respect blocked roads

            int weight = roads[roadId].weight;
            int newDist = dist[u] + weight;
            if (newDist < dist[v]) {
                dist[v] = newDist;
                prev[v] = u;
                minHeap.push(make_pair(newDist, v));
            }
        }
    }
}

vector<int> Graph::getPath(const vector<int>& prev, int src, int dst) {
    vector<int> path;
    if (prev[dst] == -1 && dst != src) return path; // unreachable

    for (int cur = dst; cur != -1; cur = prev[cur])
        path.push_back(cur);
    reverse(path.begin(), path.end());
    return path;
}

// ─── Display helpers ────────────────────────────────────────────
void Graph::printResult(int src, int dst, const vector<int>& dist, const vector<int>& prev) {
    cout << "\n============================================================\n";
    cout << "               EMERGENCY ROUTE RESULT\n";
    cout << "============================================================\n";
    cout << "  Source      : " << names[src] << "\n";
    cout << "  Destination : " << names[dst] << "\n\n";

    if (dist[dst] == INF) {
        cout << "  [!] UNREACHABLE: No path exists between these locations.\n";
        cout << "      (Disconnected road network or blocked routes)\n";
        return;
    }

    vector<int> path = getPath(prev, src, dst);
    cout << "  [OK] SHORTEST PATH FOUND\n";
    cout << "  Total travel time: " << dist[dst] << " minutes\n\n";
    cout << "  Turn-by-Turn Directions:\n";
    cout << "  " << string(50, '-') << "\n";
    for (size_t i = 0; i < path.size(); i++) {
        if (i == 0) {
            cout << "  START  ->  " << names[path[i]] << "\n";
        } else {
            int segTime = 0;
            int prevNode = path[i - 1];
            int curNode = path[i];
            for (size_t k = 0; k < adj[prevNode].size(); k++) {
                if (adj[prevNode][k].first == curNode) {
                    segTime = roads[adj[prevNode][k].second].weight;
                    break;
                }
            }
            cout << "  Step " << i << "   ->  " << names[path[i]]
                 << "  (" << segTime << " min)\n";
        }
    }
    cout << "  " << string(50, '-') << "\n";
    cout << "  ARRIVE    ->  " << names[dst] << "\n";
    cout << "  Total     :   " << dist[dst] << " minutes\n\n";
}

void Graph::printDistanceTable(int src, const vector<int>& dist) {
    cout << "\n  Distances from " << names[src] << ":\n";
    cout << "  " << string(40, '-') << "\n";
    cout << left << setw(28) << "  Location" << "Distance (min)\n";
    cout << "  " << string(40, '-') << "\n";
    for (int i = 0; i < numNodes; i++) {
        cout << "  " << left << setw(26) << names[i];
        if (dist[i] == INF) cout << "Unreachable\n";
        else cout << dist[i] << " min\n";
    }
}

void Graph::printLocationMenu() const {
    cout << "\n============================================================\n";
    cout << "   Location IDs\n";
    cout << "------------------------------------------------------------\n";
    for (int i = 0; i < numNodes; i++) {
        cout << "     " << i << ". " << names[i] << "\n";
    }
    cout << "============================================================\n";
}

// ─── Pre-built sample network ───────────────────────────────────
Graph buildPeshawarGraph() {
    /*
     * Nodes (12 major Peshawar intersections / landmarks):
     *   0  Peshawar General Hospital (Dispatch)
     *   1  Saddar (Police Lines)
     *   2  Cantt Railway Station
     *   3  Qissa Khwani Bazaar
     *   4  Khyber Teaching Hospital
     *   5  Hayatabad Phase 1
     *   6  University Road (UET)
     *   7  Ring Road Interchange
     *   8  Pajagi Road
     *   9  Gulbahar Colony
     *   10 Dalazak Road
     *   11 Warsak Road
     *
     * Edge weights = average travel time in minutes.
     */
    const int N = 12;
    Graph g(N);

    g.addLocation(0,  "Peshawar General Hospital");
    g.addLocation(1,  "Saddar (Police Lines)");
    g.addLocation(2,  "Cantt Railway Station");
    g.addLocation(3,  "Qissa Khwani Bazaar");
    g.addLocation(4,  "Khyber Teaching Hospital");
    g.addLocation(5,  "Hayatabad Phase 1");
    g.addLocation(6,  "University Road (UET)");
    g.addLocation(7,  "Ring Road Interchange");
    g.addLocation(8,  "Pajagi Road");
    g.addLocation(9,  "Gulbahar Colony");
    g.addLocation(10, "Dalazak Road");
    g.addLocation(11, "Warsak Road");

    g.addRoad(0, 1,  8);
    g.addRoad(0, 3,  10);
    g.addRoad(1, 2,  7);
    g.addRoad(1, 3,  6);
    g.addRoad(1, 9,  12);
    g.addRoad(2, 3,  9);
    g.addRoad(2, 4,  14);
    g.addRoad(3, 9,  8);
    g.addRoad(4, 5,  11);
    g.addRoad(4, 6,  7);
    g.addRoad(5, 6,  9);
    g.addRoad(5, 7,  13);
    g.addRoad(6, 7,  10);
    g.addRoad(6, 8,  15);
    g.addRoad(7, 8,  12);
    g.addRoad(7, 10, 18);
    g.addRoad(8, 10, 20);
    g.addRoad(9, 10, 14);
    g.addRoad(10, 11, 9); // node 11 has only one connection -> edge case demo

    return g;
}
