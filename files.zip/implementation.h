/*
 * ============================================================
 *  implementation.h
 *  Smart Emergency Route Planner - Peshawar City
 *  CSE-210L Data Structures & Algorithms Lab
 *
 *  Author      : Sher Nawaz (24PWCSE2352)
 *  Department  : Computer Systems Engineering
 *  University  : UET Peshawar
 *
 *  This header only declares the Graph class and its public
 *  interface. All logic lives in implementation.cpp so that
 *  main.cpp can stay short and readable for a viva/demo.
 * ============================================================
 */

#ifndef IMPLEMENTATION_H
#define IMPLEMENTATION_H

#include <vector>
#include <string>
#include <map>

// Large value standing in for "infinity"
const int INF = 1000000000;

// A single road between two locations. Stored once in a master
// list (roads) so that "blocking" a road is a single flag flip
// that both directions of travel automatically respect.
struct RoadEdge {
    int u;
    int v;
    int weight;   // travel time in minutes
    bool blocked; // true => Dijkstra will not use this road
};

class Graph {
private:
    int numNodes;

    // adj[u] = list of (neighbourId, roadId) pairs.
    // roadId indexes into `roads`, so weight/blocked status is
    // looked up in one place instead of being duplicated.
    std::vector< std::vector< std::pair<int, int> > > adj;

    std::vector<std::string> names;          // node id -> name
    std::map<std::string, int> nameToId;     // name -> node id
    std::vector<RoadEdge> roads;             // master edge list

public:
    Graph(int n = 0);

    // -- Setup --
    void setNumNodes(int n);
    void addLocation(int id, const std::string& name);
    int  addRoad(int u, int v, int travelTimeMinutes); // returns roadId

    // -- Lookups --
    std::string getName(int id) const;
    int  getNumNodes() const;
    int  getRoadCount() const;
    int  findRoadId(int u, int v) const; // -1 if no such road

    // -- Road blocking (new feature) --
    bool blockRoad(int u, int v);
    bool unblockRoad(int u, int v);
    void listRoads() const;

    // -- Core algorithm --
    void dijkstra(int src, std::vector<int>& dist, std::vector<int>& prev);
    std::vector<int> getPath(const std::vector<int>& prev, int src, int dst);

    // -- Display helpers --
    void printResult(int src, int dst, const std::vector<int>& dist,
                      const std::vector<int>& prev);
    void printDistanceTable(int src, const std::vector<int>& dist);
    void printLocationMenu() const;
};

// Pre-built demo network (the original 12-node Peshawar map).
// Kept here so main.cpp can offer it as a quick "load sample data"
// option alongside manual entry.
Graph buildPeshawarGraph();

#endif // IMPLEMENTATION_H
