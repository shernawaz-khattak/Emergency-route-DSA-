/*
 * ============================================================
 *  main.cpp
 *  Smart Emergency Route Planner - Peshawar City
 *  CSE-210L Data Structures & Algorithms Lab - Open Ended Lab
 *
 *  Author      : Sher Nawaz (24PWCSE2352)
 *  Department  : Computer Systems Engineering
 *  University  : UET Peshawar
 *  Semester    : 4th Semester
 *
 *  This file is deliberately kept high-level. Every step of the
 *  program is one clearly named function call, so the whole
 *  flow can be explained to the instructor in one glance:
 *
 *      1. buildNetwork()      -> get a Graph (sample or manual)
 *      2. mainMenuLoop()      -> repeatedly offer 3 actions:
 *           a. findShortestRoute()   (Dijkstra query)
 *           b. manageRoadBlocks()    (block/unblock a road)
 *           c. viewAllRoads()        (list roads + status)
 *
 *  All graph/algorithm details are hidden inside implementation.cpp;
 *  main.cpp never touches adjacency lists directly.
 * ============================================================
 */

#include "implementation.h"
#include <iostream>
#include <string>
#include <sstream>
#include <limits>

using namespace std;

// ─── Small input helpers ────────────────────────────────────────
string intToStr(int n) {
    ostringstream oss;
    oss << n;
    return oss.str();
}

int askInt(const string& prompt) {
    int value;
    cout << prompt;
    cin >> value;
    return value;
}

// Call this once after the LAST cin >> before you start using getline,
// so the leftover '\n' left behind by >> doesn't get read as an
// empty/short line.
void clearInputLine() {
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

string askLine(const string& prompt) {
    string value;
    cout << prompt;
    getline(cin, value);
    return value;
}

bool isValidNode(const Graph& g, int id) {
    return id >= 0 && id < g.getNumNodes();
}

// ─── Step 1: Build the network ──────────────────────────────────
// Lets the user either load the built-in Peshawar sample map or
// type in their own city/network from scratch.
Graph buildNetworkManually() {
    int n = askInt("Enter number of locations (nodes): ");
    clearInputLine(); // flush the newline left over from cin >> n
    Graph g(n);

    cout << "\nEnter the name of each location:\n";
    for (int i = 0; i < n; i++) {
        string name = askLine("  Location " + intToStr(i) + " name: ");
        g.addLocation(i, name);
    }

    int roadCount = askInt("\nHow many roads (edges) do you want to add? ");
    cout << "For each road enter: fromID toID travelTimeMinutes\n";
    for (int i = 0; i < roadCount; i++) {
        cout << "  Road " << i + 1 << ": ";
        int u, v, w;
        cin >> u >> v >> w;
        if (!isValidNode(g, u) || !isValidNode(g, v)) {
            cout << "    [X] Invalid location ID(s), road skipped.\n";
            continue;
        }
        g.addRoad(u, v, w);
    }
    return g;
}

Graph buildNetwork() {
    cout << "\n============================================================\n";
    cout << "  Network Setup\n";
    cout << "============================================================\n";
    cout << "  1. Use sample Peshawar city network (12 locations)\n";
    cout << "  2. Enter my own locations and roads manually\n";
    int choice = askInt("  Choice: ");

    if (choice == 2) {
        return buildNetworkManually();
    }
    return buildPeshawarGraph(); // default / fallback
}

// ─── Step 2a: Shortest route query ──────────────────────────────
void findShortestRoute(Graph& g) {
    g.printLocationMenu();

    int src = askInt("\nEnter Source Location ID      : ");
    int dst = askInt("Enter Destination Location ID : ");

    if (!isValidNode(g, src) || !isValidNode(g, dst)) {
        cout << "\n  [X] Invalid ID. Please enter a value between 0 and "
             << g.getNumNodes() - 1 << ".\n";
        return;
    }
    if (src == dst) {
        cout << "\n  [OK] Source and destination are the same. No travel needed.\n";
        return;
    }

    vector<int> dist, prev;
    g.dijkstra(src, dist, prev);

    g.printResult(src, dst, dist, prev);
    g.printDistanceTable(src, dist);
}

// ─── Step 2b: Road blocking feature ─────────────────────────────
void manageRoadBlocks(Graph& g) {
    g.listRoads();

    cout << "\n  1. Block a road\n";
    cout << "  2. Unblock a road\n";
    cout << "  3. Back to main menu\n";
    int action = askInt("  Choice: ");
    if (action != 1 && action != 2) return;

    g.printLocationMenu();
    int u = askInt("Enter first location ID  : ");
    int v = askInt("Enter second location ID : ");

    if (!isValidNode(g, u) || !isValidNode(g, v)) {
        cout << "\n  [X] Invalid location ID(s).\n";
        return;
    }

    bool success = (action == 1) ? g.blockRoad(u, v) : g.unblockRoad(u, v);

    if (!success) {
        cout << "\n  [X] No direct road exists between "
             << g.getName(u) << " and " << g.getName(v) << ".\n";
    } else if (action == 1) {
        cout << "\n  [OK] Road between " << g.getName(u) << " and "
             << g.getName(v) << " is now BLOCKED.\n"
             << "      Dijkstra will route around it.\n";
    } else {
        cout << "\n  [OK] Road between " << g.getName(u) << " and "
             << g.getName(v) << " is now OPEN again.\n";
    }
}

// ─── Step 2c: View roads ────────────────────────────────────────
void viewAllRoads(const Graph& g) {
    g.listRoads();
}

// ─── Step 3: Top-level menu loop ────────────────────────────────
void showWelcome() {
    cout << "\n============================================================\n";
    cout << "  CSE-210L Open Ended Lab\n";
    cout << "  Smart Emergency Route Planner - Peshawar City\n";
    cout << "  Author: Sher Nawaz | 24PWCSE2352 | UET Peshawar\n";
    cout << "  Algorithm: Dijkstra's Shortest Path (min-heap)\n";
    cout << "============================================================\n";
}

void showGoodbye() {
    cout << "\n  Thank you for using the Emergency Route Planner.\n\n";
}

void mainMenuLoop(Graph& g) {
    int choice = 0;
    while (choice != 4) {
        cout << "\n============================================================\n";
        cout << "  Main Menu\n";
        cout << "------------------------------------------------------------\n";
        cout << "  1. Find shortest emergency route\n";
        cout << "  2. Block / unblock a road\n";
        cout << "  3. View all roads and their status\n";
        cout << "  4. Exit\n";
        cout << "============================================================\n";
        choice = askInt("  Choice: ");

        switch (choice) {
            case 1: findShortestRoute(g);  break;
            case 2: manageRoadBlocks(g);   break;
            case 3: viewAllRoads(g);       break;
            case 4: break; // exit, loop condition handles it
            default: cout << "\n  [X] Invalid choice, try again.\n";
        }
    }
}

// ─── Driver ──────────────────────────────────────────────────────
int main() {
    showWelcome();
    Graph g = buildNetwork();
    mainMenuLoop(g);
    showGoodbye();
    return 0;
}
